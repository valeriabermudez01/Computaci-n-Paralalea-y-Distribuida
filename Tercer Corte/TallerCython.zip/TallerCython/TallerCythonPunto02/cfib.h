/* Universidad Sergio Arboleda 
	Fecha : 21-04-2022
	Autor : Valeria Bermúdez
	Materia : Parallel Computing
	Tema : Interfaz 
*/

#ifndef __CFIB_H__
#define __CFIB_H__

double cfib(int n);

#endif
